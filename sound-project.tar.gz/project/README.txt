Sound installer payload

Contains only site/index.html, site/track.mp3, 49 site/*.webm files,
and CONTENTS.sha256 required by deploy-sound-wizard.sh.
No source server configuration or inventory is included.
The installer generates Nginx, UFW rules and the SSH Fail2ban jail;
Certbot manages certificates on the destination server.
SSH configuration is not restored or changed.
The website and media bytes are unchanged from the original backup.
